#include <iostream>
#include <conio.h>
using namespace std;

int main() 
{
	cout<<"silahkan mengecek username dan password anda"<<endl;
	
	cout<<" °=°=°=°=°=°=°=°=°=°"<<endl;
	
	cout<<"silahkan mengisi halaman registrasi dan halaman login"<<endl;
	cout<<"°=°=°=°=°=°=°=°=°=°"<<endl;
	
	
	
	string name,pass;
	
	cout<<"=== halaman registrasi ==="<<endl;
    cout<<"username = ";
	cin>>name;
	cout<<"password = ";
	cin>>pass;
	cout<<"\n\n";
	
	cout<<"== halaman login =="<<endl;
	cout<<"Username : ";
	cin>>name;
	cout<< "Password : "; 
	cin>>pass;
	cout<<"\n\n";
	
	if (name == "SriAyuLestari" && pass == "12345678ab"){
		cout << "Hallo SriAyuLestari"<<endl;

		cout<<"anda telah berhasil login ke akun anda"<<endl;
	}
	
	else{
		cout << "Password atau Username anda salah"<<endl;
	} 
	
	cout<<endl;

		cout<<"terima kasih telah menggunakan program ini";

	return 0;
}