#include <iostream>
using namespace std;
int main(){
    
cout << "|Tugas Daspro Menghitung Volume Kubus Oleh;|\n";
    cout << "Nama : Gleen Marcell Pabbicara\n";
    cout << "Nim : F1G121020\n";
    cout << "\n";
    int s,volume;

    cout<<"masukan sisi kubus : ";
    cin>>s;

    volume=s*s*s;
    cout<<"volume kubus adalah "<<volume;
    return 0;

}
