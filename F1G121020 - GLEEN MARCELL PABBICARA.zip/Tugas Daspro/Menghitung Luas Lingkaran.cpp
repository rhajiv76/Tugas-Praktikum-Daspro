#include <iostream>
#include <conio.h>
using namespace std;
int main()
  {
    cout << "|Tugas Daspro Menghitung Luas Lingkaran Oleh;|\n";
    cout << "Nama : Gleen Marcell Pabbicara\n";
    cout << "Nim : F1G121020\n";
    cout << "\n";
    float luas, phi=3.14;
    int r;
    cout<<"Masukan Jari-jari : ";
    cin>>r;
    
    luas=phi*r*r;

    cout<<"Luas Lingkaran = "<<luas<<endl;
  getch();
  }