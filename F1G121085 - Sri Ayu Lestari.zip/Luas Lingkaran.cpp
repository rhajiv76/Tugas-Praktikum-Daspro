#include <iostream>
using namespace std;

int main() {
  std::cout << "SRI AYU LESTARI\n";
          cout << "F1G121084\n";
          cout << "ILMU KOMPUTER\n";

  float a,b,c,hasil;
  b = 3.14;
  cout<<"masukkan nilai jari-jari =";
  cin>>a;
  c = a * a;
  cout<<"r� = "<<c<<endl;
  cout<<"diketahui "<<b<<"�"<<c<<endl;
  hasil = b * c;
  cout<<"untuk hasil luas lingkaran = "<<hasil<<"cm�\n";
  
  return 0;
}
