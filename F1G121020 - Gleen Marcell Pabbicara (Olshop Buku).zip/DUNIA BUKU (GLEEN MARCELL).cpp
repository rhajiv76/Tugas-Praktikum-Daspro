#include <iostream>
using namespace std;

int main(){

	int es, Jumlah_buku, harga_1, harga_2, harga_3,harga_4,harga_total;
	char pilihan;
	awal:
	cout<<"|||============================== DUNIA BUKU ONLINE STORE==========================||| "<<endl;
	cout<<endl;
	cout<<" Selamat datang di Dunia Buku Online Store silahakan memesan menu yang anda ingin di daftar buku"<<endl;
	cout<<endl;
	cout<<" Daftar buku = "<<endl;
	cout<<" 1. Calculus Purcell Rp150.000 " <<endl;
	cout<<" 2. Diktat OSN Fisika 2021 Rp100.000 " <<endl;
	cout<<" 3. Fisika Dasar 1 Rp150.000 " <<endl;
	cout<<" 4. Fisika Dasar 2 Rp200.000"<<endl;
	cout<<endl;
	harga_1 = 150000;
	harga_2 = 100000;
	harga_3 = 150000;
	harga_4 = 200000;
	cout<<"masukkan pilihan buku anda = ";
	cin >> es;
	switch(es){
		case 1:
			cout<<"masukkan jumlah buku yang ingin anda pesan = ";
			cin>>Jumlah_buku;{
			system ("cls");
			}harga_total = Jumlah_buku * harga_1;
			cout<< "harga_total = "<< Jumlah_buku * harga_1<< " Rp "<<endl;
			cout<<" Calcukus Purcell, sejumlah " << Jumlah_buku << " "
			      ", buku yang anda inginkan siap diantarkan seharga Rp" << harga_total <<endl;
			calculus_purcell:
			cout<<"apakah anda ingin memesan buku lain? (y/n)"<<endl;
			cout<<"masukkan pilihan anda = ";
			cin>>pilihan;
			if(pilihan == 'y'){
		    	system("cls");
		    	goto awal;
		    }		else if(pilihan == 'n'){
		    		system("cls");
		    		cout<<"Terimakasih telah memesan buku di Dunia Buku"<<endl;
		    		cout<<endl;
		    		cout<<"selamat membaca"<<endl;
			}			else{
						cout<<"pilihan yang anda masukkan salah";
							goto calculus_purcell;
			}
		break;
			case 2:
			cout<<"masukkan jumlah buku yang ingin anda pesan = ";
			cin>>Jumlah_buku;{
			system ("cls");
			}harga_total = Jumlah_buku * harga_1;
			cout<< "harga_total = "<< Jumlah_buku * harga_1<< " Rp "<<endl;
			cout<<" Diktat OSN Fisika 2021, sejumlah  " << Jumlah_buku << ", buku yang anda inginkan siap diantarkan seharga Rp" << harga_total <<endl;
			diktat_osn:
			cout<<"apakah anda ingin memesan lagi? (y/n)"<<endl;
			cout<<"masukkan pilihan anda = ";
			cin>>pilihan;
			if(pilihan == 'y'){
		    	system("cls");
		    	goto awal;
		    }		else if(pilihan == 'n'){
		    		system("cls");
		    		cout<<"Terimakasih telah memesan di dunia buku online store"<<endl;
		    		cout<<endl;
		    		cout<<"selamat membaca"<<endl;
			}			else{
						cout<<"pilihan yang anda masukkan salah";
							goto diktat_osn;
			}
		break;
			case 3:
			cout<<"masukkan jumlah buku yang ingin anda pesan = ";
			cin>>Jumlah_buku;{
			system ("cls");
			}harga_total = Jumlah_buku * harga_1;
			cout<< "harga_total = "<< Jumlah_buku * harga_1<< " Rp "<<endl;
			cout<<" Fisika Dasar 1, sejumlah " << Jumlah_buku << ", buku yang anda inginkan siap diantarkan seharga Rp" << harga_total <<endl;
			fisika_1:
			cout<<"apakah anda ingin memesan lagi? (y/n)"<<endl;
			cout<<"masukkan pilihan anda = ";
			cin>>pilihan;
			if(pilihan == 'y'){
		    	system("cls");
		    	goto awal;
		    }		else if(pilihan == 'n'){
		    		system("cls");
		    		cout<<"Terimakasih telah memesan di dunia buku online store"<<endl;
		    		cout<<endl;
		    		cout<<"selamat membaca"<<endl;
			}			else{
						cout<<"pilihan yang anda masukkan salah";
							goto fisika_1;
			}
		break;
		case 4:
			cout<<"masukkan jumlah buku yang ingin anda pesan = ";
			cin>>Jumlah_buku;{
			system ("cls");
			}harga_total = Jumlah_buku * harga_1;
			cout<< "harga_total = "<< Jumlah_buku * harga_1<< " Rp "<<endl;
			cout<<" Fisika Dasar 2, sejumlah " << Jumlah_buku << ", buku yang anda inginkan siap diantarkan seharga Rp" << harga_total <<endl;
			fisika_2:
			cout<<"apakah anda ingin memesan lagi? (y/n)"<<endl;
			cout<<"masukkan pilihan anda = ";
			cin>>pilihan;
			if(pilihan == 'y'){
		    	system("cls");
		    	goto awal;
		    }		else if(pilihan == 'n'){
		    		system("cls");
		    		cout<<"Terimakasih telah memesan di dunia buku online store"<<endl;
		    		cout<<endl;
		    		cout<<"selamat menikmati"<<endl;
			}			else{
						cout<<"pilihan yang anda masukkan salah";
							goto fisika_2;
			}
			break;
			default:
			cout<<"Masukkan Nomor Pesanan Yang sesuai \n";

	}
}
